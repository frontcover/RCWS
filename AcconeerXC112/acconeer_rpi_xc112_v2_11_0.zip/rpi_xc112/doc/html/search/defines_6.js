var searchData=
[
  ['main_5fthread_5fidle_5fsleep_5fus_1873',['MAIN_THREAD_IDLE_SLEEP_US',['../acc__exploration__server__linux_8c.html#a2dbe983e63990043cb77c490a373944f',1,'acc_exploration_server_linux.c']]],
  ['max_5fbackground_5flength_1874',['MAX_BACKGROUND_LENGTH',['../example__detector__distance__recorded_8c.html#a1935f556b51815978f529368ce06cc00',1,'MAX_BACKGROUND_LENGTH():&#160;example_detector_distance_recorded.c'],['../ref__app__tank__level_8c.html#a1935f556b51815978f529368ce06cc00',1,'MAX_BACKGROUND_LENGTH():&#160;ref_app_tank_level.c']]],
  ['max_5fcommand_5fsize_1875',['MAX_COMMAND_SIZE',['../acc__exploration__server__linux_8c.html#ab95c4556ea9e5b815392d36c3d7b2ec0',1,'acc_exploration_server_linux.c']]],
  ['max_5fleak_5famplitude_1876',['MAX_LEAK_AMPLITUDE',['../ref__app__parking_8c.html#aacde75fc94a20bbba826af3dc6d83664',1,'ref_app_parking.c']]],
  ['max_5fspi_5ftransfer_5fsize_1877',['MAX_SPI_TRANSFER_SIZE',['../acc__libspi_8h.html#a107842648e898ef838bd58e4307ea094',1,'acc_libspi.h']]]
];
