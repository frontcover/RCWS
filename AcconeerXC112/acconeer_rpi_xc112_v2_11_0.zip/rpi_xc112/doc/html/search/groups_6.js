var searchData=
[
  ['log_20integration_1905',['Log Integration',['../group__Log.html',1,'']]]
];
