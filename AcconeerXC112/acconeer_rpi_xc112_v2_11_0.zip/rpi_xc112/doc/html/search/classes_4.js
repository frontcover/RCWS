var searchData=
[
  ['metadata_5fopt_5ft_996',['metadata_opt_t',['../structmetadata__opt__t.html',1,'']]]
];
