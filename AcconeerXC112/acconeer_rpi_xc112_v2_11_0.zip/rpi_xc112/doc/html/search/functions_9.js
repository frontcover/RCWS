var searchData=
[
  ['record_5fbackground_1502',['record_background',['../example__detector__distance__recorded_8c.html#a545ceeb81dcfe1d8ab52cba40ae5d1ae',1,'record_background(acc_detector_distance_configuration_t distance_configuration):&#160;example_detector_distance_recorded.c'],['../ref__app__tank__level_8c.html#a1b38346b79b3e4b2bbb599743176b552',1,'record_background(acc_detector_distance_handle_t *distance_handle, acc_detector_distance_configuration_t distance_configuration, float *range_gain, uint16_t *background, uint16_t background_length):&#160;ref_app_tank_level.c']]],
  ['record_5fbackgrounds_1503',['record_backgrounds',['../ref__app__tank__level_8c.html#ab1a6c6e2c86b981a980905e1068357e9',1,'ref_app_tank_level.c']]],
  ['restart_5fservice_1504',['restart_service',['../example__error__handling_8c.html#a5d45c9e2b006f542e79d2966b9259cbd',1,'example_error_handling.c']]],
  ['run_5ftest_1505',['run_test',['../example__bring__up_8c.html#a1e6307b53e6eaff0385c6f4380c0b115',1,'example_bring_up.c']]]
];
