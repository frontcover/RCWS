var searchData=
[
  ['chip_1526',['chip',['../acc__libgpiod_8c.html#aaddc701b695be2b39390334da05025e9',1,'acc_libgpiod.c']]],
  ['client_5fsocket_1527',['client_socket',['../structexploration__server__t.html#abd6790a57b89b7de3742143a6e79112d',1,'exploration_server_t']]],
  ['close_5faddition_1528',['close_addition',['../structacc__detector__obstacle__configuration__threshold__t.html#a3dc1b299f4c82e21961a63d4c05508fc',1,'acc_detector_obstacle_configuration_threshold_t']]],
  ['close_5fbackground_1529',['close_background',['../ref__app__tank__level_8c.html#a666898adebb5593c5728f9edc565dcbb',1,'ref_app_tank_level.c']]],
  ['close_5fbackground_5flength_1530',['close_background_length',['../ref__app__tank__level_8c.html#a181d2da361d26782e649040b3f12c742',1,'ref_app_tank_level.c']]],
  ['close_5frange_5fgain_1531',['close_range_gain',['../ref__app__tank__level_8c.html#a637108f286868074a553e2d9a249ed30',1,'ref_app_tank_level.c']]],
  ['closest_5fdetection_5fm_1532',['closest_detection_m',['../structacc__detector__distance__result__info__t.html#a1160e2d9b04fd3054d5013d91d1bdcb9',1,'acc_detector_distance_result_info_t']]],
  ['command_5fbuffer_1533',['command_buffer',['../acc__exploration__server__linux_8c.html#a584850828ad0ab590bbdab7ce901b19c',1,'acc_exploration_server_linux.c']]],
  ['consumer_1534',['consumer',['../structgpiod__line__request__config.html#a130194a15629e74cc66c8c6f4b30a00d',1,'gpiod_line_request_config']]]
];
