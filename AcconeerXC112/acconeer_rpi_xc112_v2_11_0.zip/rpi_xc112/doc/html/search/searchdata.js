var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuw",
  1: "aegims",
  2: "adeghioprstu",
  3: "acdeghimprsuw",
  4: "abcdefghilmnoprstuw",
  5: "agrsw",
  6: "ags",
  7: "aegips",
  8: "_adeglmnprsu",
  9: "adeghiloprs",
  10: "adehioprstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

