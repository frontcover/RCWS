var searchData=
[
  ['_5fposix_5fc_5fsource_0',['_POSIX_C_SOURCE',['../acc__service__data__logger_8c.html#a3024ccd4a9af5109d24e6c57565d74a1',1,'acc_service_data_logger.c']]]
];
