var group__OS =
[
    [ "acc_rss_integration_os_primitives_t", "structacc__rss__integration__os__primitives__t.html", [
      [ "gettime", "structacc__rss__integration__os__primitives__t.html#a8c6e9f7b685ab4fb2e839891cdfec069", null ],
      [ "mem_alloc", "structacc__rss__integration__os__primitives__t.html#a87e0ebad5f0794be97218e6537506f8a", null ],
      [ "mem_free", "structacc__rss__integration__os__primitives__t.html#a253047dfd2e9692f15885fb1d07c301c", null ]
    ] ],
    [ "acc_os_get_time_function_t", "group__OS.html#ga0b1deb9ca88cded9b55ca7dbdae49062", null ],
    [ "acc_os_mem_alloc_function_t", "group__OS.html#ga6da3e04201684415a639fbd41bc2487d", null ],
    [ "acc_os_mem_free_function_t", "group__OS.html#ga7eb3ce6b829b2705c8eb7ffa72f7aba2", null ]
];