var group__Opimization =
[
    [ "acc_optimization_t", "structacc__optimization__t.html", [
      [ "transfer16", "structacc__optimization__t.html#a87346bf8f88efcfdce26539798e8d80d", null ]
    ] ],
    [ "acc_sensor_transfer16_function_t", "group__Opimization.html#ga7f146579a2d215d86d44d3ef73200b0d", null ]
];