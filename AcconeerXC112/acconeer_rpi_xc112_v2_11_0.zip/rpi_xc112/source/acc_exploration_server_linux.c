// Copyright (c) Acconeer AB, 2021-2022
// All rights reserved
// This file is subject to the terms and conditions defined in the file
// 'LICENSES/license_acconeer.txt', (BSD 3-Clause License) which is part
// of this source code package.

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#include "acc_definitions_common.h"
#include "acc_exploration_server_base.h"
#include "acc_exploration_server_system_a111.h"


#define US_TICKS_PER_SECOND       (1000000)
#define NS_PER_TICKS              (1000)
#define MAIN_THREAD_IDLE_SLEEP_US (200000)
#define MAX_COMMAND_SIZE          (10*1024)

static char command_buffer[MAX_COMMAND_SIZE];
static char socket_buffer[MAX_COMMAND_SIZE];

typedef struct
{
	int           server_socket;
	int           client_socket;
	struct pollfd poll_set[1];
	volatile bool shutdown;
} exploration_server_t;

static exploration_server_t exploration_server = { 0 };

/**
 * @brief Write data to socket
 *
 * @param[in] data pointer to data
 * @param[in] size data size in bytes
 *
 * @return true if successful
 */
static bool write_data_func(const void *data, uint32_t size);


/**
 * @brief Get tick
 *
 * @return The current tick
 */
static uint32_t get_tick(void);


/**
 * @brief Check if shutdown should be initiated
 *
 * @return true if shutdown should be initiated
 */
static bool do_shutdown(void);


const exploration_server_interface_t server_if = {
	.write            = write_data_func,
	.restart_input    = NULL,
	.set_baudrate     = NULL,
	.max_baudrate     = 0,
	.get_tick         = get_tick,
	.ticks_per_second = US_TICKS_PER_SECOND,          /* us ticks are used in this integration */
};


static void set_shutdown(bool shutdown)
{
	exploration_server.shutdown = shutdown;
}


static void cleanup(void)
{
	acc_exploration_server_deinit();
}


static bool write_data_func(const void *data, uint32_t size)
{
	bool result = false;

	if (exploration_server.client_socket > 0)
	{
		result = write(exploration_server.client_socket, data, size) == (ssize_t)size;
	}

	return result;
}


static bool do_shutdown(void)
{
	return exploration_server.shutdown;
}


static uint32_t get_tick(void)
{
	struct timespec time_ts = {0};

	/* us ticks are used in this integration */
	clock_gettime(CLOCK_MONOTONIC, &time_ts);
	return (uint32_t)(time_ts.tv_sec * 1000000 + time_ts.tv_nsec / 1000);
}


static bool start_server_socket(void)
{
	int                s;
	struct sockaddr_in addr;

	if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		fprintf(stderr, "ERROR: socket(AF_INET, SOCK_STREAM, 0): (%u) %s\n", errno, strerror(errno));
		return false;
	}

	if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &(int){1 }, sizeof(int)) < 0)
	{
		fprintf(stderr, "ERROR: setsockopt(SO_REUSEADDR): (%u) %s\n", errno, strerror(errno));
	}

	memset(&addr, 0, sizeof(addr));
	addr.sin_family      = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port        = htons(6110);

	if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0)
	{
		fprintf(stderr, "ERROR: bind(): (%u) %s\n", errno, strerror(errno));
		close(s);
		return false;
	}

	if (listen(s, 10) < 0)
	{
		fprintf(stderr, "ERROR: listen(): (%u) %s\n", errno, strerror(errno));
		close(s);
		return false;
	}

	exploration_server.server_socket = s;

	return true;
}


static bool wait_for_accept(void)
{
	/* Blocking wait for accept */
	exploration_server.client_socket = accept(exploration_server.server_socket, NULL, NULL);

	if (exploration_server.client_socket < 0)
	{
		return false;
	}

	return true;
}


static void setup_client_socket(void)
{
	if (setsockopt(exploration_server.client_socket, SOL_SOCKET, SO_KEEPALIVE, &(int){1 }, sizeof(int)) < 0)
	{
		fprintf(stderr, "ERROR:setsockopt(SO_KEEPALIVE): (%u) %s\n", errno, strerror(errno));
	}

	if (setsockopt(exploration_server.client_socket, IPPROTO_TCP, TCP_NODELAY, &(int){1 }, sizeof(int)) < 0)
	{
		fprintf(stderr, "ERROR:setsockopt(TCP_NODELAY): (%u) %s\n", errno, strerror(errno));
	}

	if (setsockopt(exploration_server.client_socket, SOL_SOCKET, SO_SNDBUF, &(int){200000 }, sizeof(int)) < 0)
	{
		fprintf(stderr, "ERROR:setsockopt(SO_SNDBUF): (%u) %s\n", errno, strerror(errno));
	}
}


static bool poll_events(struct timespec *poll_wait)
{
	bool success = true;

	/* Wait for poll_wait time or until a socket event occurs */
	int nof_events = ppoll(exploration_server.poll_set, 1, poll_wait, NULL);

	if (nof_events > 0)
	{
		short returned_event = exploration_server.poll_set[0].revents;
		if (returned_event & POLLERR)
		{
			/* Socket error, break */
			success = false;
		}
		else if (returned_event & POLLIN)
		{
			int len = read(exploration_server.client_socket, socket_buffer, sizeof(socket_buffer));
			if (len >= 1)
			{
				/* Put data from socket */
				acc_exploration_server_put_buffer_from_client(socket_buffer, len);
			}
			else if (len == 0)
			{
				/* Client socket disconnected */
				success = false;
			}
			else
			{
				/* Interrupted by signal */
				success = false;
			}
		}
	}
	else
	{
		/* POLL TIMEOUT or POLL ERROR, just continue */
	}

	return success;
}


static void main_sig_handler(int sig)
{
	printf("\nMain thread interrupted [%d]\n", sig);
	signal(sig, SIG_IGN);
	set_shutdown(true);
}


static void print_usage(char *application_name)
{
	fprintf(stderr, "Usage: %s [OPTION]...\n", application_name);
	fprintf(stderr, "\n");
	fprintf(stderr, "-h, --help                      this help\n");
	fprintf(stderr, "-l, --log-level                 the log level (error/warning/info/verbose/error)\n");
}


int main(int argc, char *argv[])
{
	static struct option long_options[] =
	{
		{"help",             no_argument,       0,      'h'},
		{"log-level",        required_argument, 0,      'l'},
		{NULL,               0,                 NULL,   0}
	};

	int character_code;
	int option_index = 0;

	acc_log_level_t log_level = ACC_LOG_LEVEL_ERROR;

	while ((character_code = getopt_long(argc, argv, "h?l:", long_options, &option_index)) != -1)
	{
		switch (character_code)
		{
			case 'h':
			case '?':
			{
				print_usage(basename(argv[0]));
				return EXIT_FAILURE;
			}
			case 'l':
			{
				if (strcmp(optarg, "debug") == 0)
				{
					log_level = ACC_LOG_LEVEL_DEBUG;
				}
				else if (strcmp(optarg, "verbose") == 0)
				{
					log_level = ACC_LOG_LEVEL_VERBOSE;
				}
				else if (strcmp(optarg, "info") == 0)
				{
					log_level = ACC_LOG_LEVEL_INFO;
				}
				else if (strcmp(optarg, "warning") == 0)
				{
					log_level = ACC_LOG_LEVEL_WARNING;
				}
				else if (strcmp(optarg, "error") == 0)
				{
					log_level = ACC_LOG_LEVEL_ERROR;
				}
				else
				{
					fprintf(stderr, "ERROR: Unknown log-level '%s'\n", optarg);
					return EXIT_FAILURE;
				}

				break;
			}
			default:
				break;
		}
	}

	acc_exploration_server_register_all_services();

	if (!acc_exploration_server_init(command_buffer, sizeof(command_buffer), "linux", log_level))
	{
		return EXIT_FAILURE;
	}

	/* setup signal handler */
	struct sigaction sa = { 0 };
	sa.sa_handler = main_sig_handler;
	if (sigaction(SIGINT, &sa, NULL) < 0)
	{
		fprintf(stderr, "ERROR: sigaction\n");
		cleanup();
		return EXIT_FAILURE;
	}

	/* Ignore broken pipe shutdown, default behavior is to close application */
	signal(SIGPIPE, SIG_IGN);

	if (!start_server_socket())
	{
		fprintf(stderr, "ERROR: Could not create socket server\n");
		cleanup();
		return EXIT_FAILURE;
	}

	/* No client socket to start with */
	exploration_server.client_socket = -1;

	while (!do_shutdown())
	{
		printf("Waiting for new connections...\n");
		fflush(stdout);

		/* Close client socket if there was any */
		if (exploration_server.client_socket > 0)
		{
			close(exploration_server.client_socket);
			exploration_server.client_socket = -1;
		}

		/* Stop streaming if there was any */
		acc_exploration_server_stop_streaming();

		/* Blocking accept */
		if (!wait_for_accept())
		{
			/* No valid accept, continue and try again... */
			continue;
		}

		/* Setup the client socket the way it should be */
		setup_client_socket();

		/* Setup poll struct */
		exploration_server.poll_set[0].fd     = exploration_server.client_socket;
		exploration_server.poll_set[0].events = POLLIN;

		printf("Got new connection.\n");
		printf("Listening for command...\n");

		while (!do_shutdown())
		{
			/* Default state is idle */
			acc_exploration_server_state_t state = ACC_EXPLORATION_SERVER_WAITING;

			/* Default wait time is zero */
			int32_t ticks_until_next = 0;

			bool success = acc_exploration_server_process(&server_if, &state, &ticks_until_next);

			if (!success)
			{
				fprintf(stderr, "ERROR: acc_exploration_server_process (%u) %s\n", errno, strerror(errno));
				break;
			}

			/* Calculate waiting time in poll_wait depending on state */
			struct timespec poll_wait      = { 0 };
			struct timespec *poll_wait_ptr = &poll_wait;

			switch (state)
			{
				case ACC_EXPLORATION_SERVER_STOPPED:
					set_shutdown(true);
					/* Stop received, do not wait for more events (continue) */
					continue;
				case ACC_EXPLORATION_SERVER_WAITING:
					/* Wait blocking until an event occurs */
					poll_wait_ptr = NULL;
					break;
				case ACC_EXPLORATION_SERVER_STREAMING:
					/* Wait full amount of us (or until a socket event occurs) */
					poll_wait.tv_sec  = ticks_until_next / US_TICKS_PER_SECOND;
					poll_wait.tv_nsec = (ticks_until_next % US_TICKS_PER_SECOND) * NS_PER_TICKS;
					break;
			}

			if (!poll_events(poll_wait_ptr))
			{
				/* Socket disconnected or other error */
				break;
			}
		}
	}

	if (exploration_server.client_socket > 0)
	{
		acc_exploration_server_end(&server_if);
		close(exploration_server.client_socket);
	}

	close(exploration_server.server_socket);

	cleanup();
	printf("Shutdown complete.\n");

	return EXIT_SUCCESS;
}
