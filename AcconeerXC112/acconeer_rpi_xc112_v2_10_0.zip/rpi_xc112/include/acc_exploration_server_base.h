// Copyright (c) Acconeer AB, 2020-2021
// All rights reserved

#ifndef ACC_EXPLORATION_SERVER_BASE_H_
#define ACC_EXPLORATION_SERVER_BASE_H_

#include <stdbool.h>

#include "acc_definitions_common.h"

/**
 * @brief Function that writes data back to the client
 *
 * @param[in] data The data to be written
 * @param[in] data The size of the data in bytes
 *
 * @return True if successful
 */
typedef bool (write_data_function_t)(const void *data, uint32_t size);

/**
 * @brief Checks if streaming is running
 *
 * @return True if running
 */
typedef bool (is_running_function_t)(void);

/**
 * @brief Function that starts streaming
 *
 * @return True if successful
 */
typedef bool (start_streaming_function_t)(void);

/**
 * @brief Function that stops streaming
 */
typedef void (stop_streaming_function_t)(void);


/**
 * @brief Function that stops streaming
 */
typedef void (restart_input_function_t)(void);


/**
 * @brief Set baudrate of server
 */
typedef void (set_baudrate_function_t)(uint32_t baudrate);


/**
 * @brief Get tick function of server
 */
typedef uint32_t (get_tick_function_t)(void);


/**
 * @brief Struct to handle input for acc_exploration_server_process_cmds
 */
typedef struct
{
	write_data_function_t      *write;
	start_streaming_function_t *start_streaming;
	stop_streaming_function_t  *stop_streaming;
	is_running_function_t      *is_running;
	restart_input_function_t   *restart_input;
	set_baudrate_function_t    *set_baudrate;
	get_tick_function_t        *get_tick;
	uint32_t                   ticks_per_second;
} exploration_server_interface_t;

/**
 * @brief Initialize the exploration server
 *
 * @param[in] buffer pointer to a command buffer
 * @param[in] buffer_size the size, in bytes, of the command buffer
 * @param[in] hw The hardware name (module/board/system)
 * @param[in] log_level The log level to use
 *
 * @return true if successful
 */
bool acc_exploration_server_init(char *buffer, size_t buffer_size, const char *hw, acc_log_level_t log_level);


/**
 * @brief De-initialize the exploration server
 */
void acc_exploration_server_deinit(void);


/**
 * @brief Put string from client into input buffer
 *
 * @param[in] buffer data from client
 * @param[in] buffer_size the size, in bytes, of the buffer
 */
void acc_exploration_server_put_buffer_from_client(const void *buffer, size_t buffer_size);


/**
 * @brief Check if the input buffer contains a complete line
 *
 * @return true if complete line is in buffer
 */
bool acc_exploration_server_have_line(void);


/**
 * @brief Process exploration server commaand
 *
 * @param[in] server_if server interface functions for process commands
 */
void acc_exploration_server_process_cmds(const exploration_server_interface_t *server_if);


/**
 * @brief End exploration server session, called to shutdown server
 *
 * @param[in] write_func function to use when writing data to client
 */
void acc_exploration_server_end(write_data_function_t *write_func);


/**
 * @brief Read data frames from sensor and send to client
 *
 * This function should be called from the streaming thread
 *
 * @param[in] server_if server interface functions
 * @param[out] ticks_until_next number of ticks until next sweep
 *
 * @return True if successful
 */
bool acc_exploration_server_read_data_frames(const exploration_server_interface_t *server_if, int32_t *ticks_until_next);


/**
 * @brief Destroy the streaming session
 */
void acc_exploration_server_destroy_session(void);


#endif
