// Copyright (c) Acconeer AB, 2021
// All rights reserved
// This file is subject to the terms and conditions defined in the file
// 'LICENSES/license_acconeer.txt', (BSD 3-Clause License) which is part
// of this source code package.

#if !defined(_GNU_SOURCE)
#define _GNU_SOURCE
#endif

#include <arpa/inet.h>
#include <complex.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <inttypes.h>
#include <inttypes.h>
#include <libgen.h>
#include <math.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <termios.h>
#include <unistd.h>

#include "acc_definitions_common.h"
#include "acc_exploration_server_base.h"
#include "acc_exploration_server_system_a111.h"


#define MAX_COMMAND_SIZE (10*1024)

static char command_buffer[MAX_COMMAND_SIZE];

typedef struct
{
	int             server_socket;
	pthread_mutex_t socket_write_lock;
	pthread_t       streaming_thread_handle;
} exploration_server_t;

typedef struct
{
	pthread_mutex_t comm_thread_data_lock;
	int             client_socket;
	bool            stop_run;
	bool            is_running;
} comm_thread_data_t;

typedef struct
{
	bool            shutdown;
	pthread_mutex_t shutdown_lock;
} main_thread_control_t;

static comm_thread_data_t    comm_thread_data    = { 0 };
static main_thread_control_t main_thread_control = { 0 };
static exploration_server_t  exploration_server  = {
	.server_socket = 0,
};


/**
 * @brief Write data to socket
 *
 * @param[in] data pointer to data
 * @param[in] size data size in bytes
 *
 * @return true if successful
 */
static bool write_data_func(const void *data, uint32_t size);


/**
 * @brief Start streaming
 *
 * @return true is successful
 */
static bool start_streaming(void);


/**
 * @brief Stop streaming
 */
static void stop_streaming(void);


/**
 * @brief Check if thread is running
 *
 * @return true if thread is running
 */
static bool check_is_running(void);


/**
 * @brief Get tick
 *
 * @return The current tick
 */
static uint32_t get_tick(void);


const exploration_server_interface_t server_if = {
	.write            = write_data_func,
	.start_streaming  = start_streaming,
	.stop_streaming   = stop_streaming,
	.is_running       = check_is_running,
	.restart_input    = NULL,
	.set_baudrate     = NULL,
	.get_tick         = get_tick,
	.ticks_per_second = 1000000,             /* us ticks are used in this integration */
};


static void set_shutdown(bool shutdown)
{
	pthread_mutex_lock(&main_thread_control.shutdown_lock);
	main_thread_control.shutdown = shutdown;
	pthread_mutex_unlock(&main_thread_control.shutdown_lock);
}


static void sig_handler(int sig)
{
	signal(sig, SIG_IGN);
	set_shutdown(true);
}


static void cleanup(void)
{
	pthread_mutex_destroy(&exploration_server.socket_write_lock);
	pthread_mutex_destroy(&comm_thread_data.comm_thread_data_lock);
	pthread_mutex_destroy(&main_thread_control.shutdown_lock);

	acc_exploration_server_deinit();

	if (exploration_server.server_socket > 0)
	{
		close(exploration_server.server_socket);
	}
}


/**
 * @brief Open a TCP socket server
 */
static int connection_open(void)
{
	int                s;
	struct sockaddr_in addr;

	if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf("socket(AF_INET, SOCK_STREAM, 0): (%u) %s", errno, strerror(errno));
		return -errno;
	}

	if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &(int){1 }, sizeof(int)) < 0)
	{
		printf("setsockopt(SO_REUSEADDR): (%u) %s", errno, strerror(errno));
	}

	memset(&addr, 0, sizeof(addr));
	addr.sin_family      = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port        = htons(6110);

	if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0)
	{
		int ret = errno;
		printf("bind(): (%u) %s", errno, strerror(errno));
		close(s);
		return -ret;
	}

	if (listen(s, 10) < 0)
	{
		int ret = errno;
		close(s);
		return -ret;
	}

	return s;
}


/**
 * @brief Set blocking communication mode for the client TCP
 */
static void set_blocking(int fd, bool blocking)
{
	int flags = fcntl(fd, F_GETFL, 0);

	if (blocking)
	{
		fcntl(fd, F_SETFL, flags & (~O_NONBLOCK));
	}
	else
	{
		fcntl(fd, F_SETFL, flags | O_NONBLOCK);
	}
}


/**
 * @brief Read data from the client
 *
 * @param[in] fd socket file descriptor
 *
 * @return true if successful
 */
static bool read_line_from_client(int fd)
{
	int  len = 1;
	char c   = 0;

	bool success = true;

	len = read(fd, &c, 1);
	if (len >= 1)
	{
		acc_exploration_server_put_buffer_from_client(&c, sizeof(c));
	}
	else if (len == 0)
	{
		success = false;
	}

	return success;
}


static bool write_data_func(const void *data, uint32_t size)
{
	pthread_mutex_lock(&exploration_server.socket_write_lock);
	bool result = write(comm_thread_data.client_socket, data, size) == (ssize_t)size;
	pthread_mutex_unlock(&exploration_server.socket_write_lock);
	return result;
}


static bool check_is_running(void)
{
	pthread_mutex_lock(&comm_thread_data.comm_thread_data_lock);
	bool ret = comm_thread_data.is_running;
	pthread_mutex_unlock(&comm_thread_data.comm_thread_data_lock);
	return ret;
}


/**
 * @brief Set if the sensor thread should stop running
 *
 * @param[in] stop_run true if the thread should stop
 */
static void set_stop_run(bool stop_run)
{
	pthread_mutex_lock(&comm_thread_data.comm_thread_data_lock);
	comm_thread_data.stop_run = stop_run;
	pthread_mutex_unlock(&comm_thread_data.comm_thread_data_lock);
}


static void stop_streaming(void)
{
	printf("Stopping all sensors.\n");
	set_stop_run(true);
	pthread_join(exploration_server.streaming_thread_handle, NULL);
}


/**
 * @brief Set if the sensor thread is running
 *
 * @param[in] is_running true if the sensor is running
 */
static void set_is_running(bool is_running)
{
	pthread_mutex_lock(&comm_thread_data.comm_thread_data_lock);
	comm_thread_data.is_running = is_running;
	pthread_mutex_unlock(&comm_thread_data.comm_thread_data_lock);
}


/**
 * @brief Check if the sensor thread should stop running
 *
 * @return true if the thread should stop
 */
static bool check_stop_run(void)
{
	pthread_mutex_lock(&comm_thread_data.comm_thread_data_lock);
	bool ret = comm_thread_data.stop_run;
	pthread_mutex_unlock(&comm_thread_data.comm_thread_data_lock);

	return ret;
}


/**
 * @brief Check if shutdown is set
 *
 * @return true if shutdown is set
 */
static bool check_shutdown(void)
{
	pthread_mutex_lock(&main_thread_control.shutdown_lock);
	bool ret = main_thread_control.shutdown;
	pthread_mutex_unlock(&main_thread_control.shutdown_lock);

	return ret;
}


/**
 * @brief Streaming thread
 */
static void *thread_start_streaming(void *param)
{
	(void)param;

	while (true)
	{
		/* us ticks are used in this integration */
		int32_t ticks_until_next = 0;
		bool    result           = acc_exploration_server_read_data_frames(&server_if, &ticks_until_next);

		if (ticks_until_next > 0)
		{
			usleep(ticks_until_next);
		}

		if (!result)
		{
			break;
		}

		if (check_stop_run())
		{
			printf("Client sent stop signal.\n");
			break;
		}
	}

	printf("Stopping sensor control\n");
	set_is_running(false);

	return NULL;
}


static bool start_streaming(void)
{
	bool result = true;

	set_stop_run(false);
	set_is_running(true);

	if (pthread_create(&exploration_server.streaming_thread_handle, NULL, &thread_start_streaming, NULL) != 0)
	{
		result = false;
		set_is_running(false);
	}

	return result;
}


static uint32_t get_tick(void)
{
	struct timespec time_ts = {0};

	/* us ticks are used in this integration */
	clock_gettime(CLOCK_MONOTONIC, &time_ts);
	return (uint32_t)(time_ts.tv_sec * 1000000 + time_ts.tv_nsec / 1000);
}


static void print_usage(char *application_name)
{
	fprintf(stderr, "Usage: %s [OPTION]...\n", application_name);
	fprintf(stderr, "\n");
	fprintf(stderr, "-h, --help                      this help\n");
	fprintf(stderr, "-l, --log-level                 the log level (error/warning/info/verbose/error)\n");
}


int main(int argc, char *argv[])
{
	static struct option long_options[] =
	{
		{"help",             no_argument,       0,      'h'},
		{"log-level",        required_argument, 0,      'l'},
		{NULL,               0,                 NULL,   0}
	};

	int character_code;
	int option_index = 0;

	acc_log_level_t log_level = ACC_LOG_LEVEL_ERROR;

	while ((character_code = getopt_long(argc, argv, "h?l:", long_options, &option_index)) != -1)
	{
		switch (character_code)
		{
			case 'h':
			case '?':
			{
				print_usage(basename(argv[0]));
				return EXIT_FAILURE;
			}
			case 'l':
			{
				if (strcmp(optarg, "debug") == 0)
				{
					log_level = ACC_LOG_LEVEL_DEBUG;
				}
				else if (strcmp(optarg, "verbose") == 0)
				{
					log_level = ACC_LOG_LEVEL_VERBOSE;
				}
				else if (strcmp(optarg, "info") == 0)
				{
					log_level = ACC_LOG_LEVEL_INFO;
				}
				else if (strcmp(optarg, "warning") == 0)
				{
					log_level = ACC_LOG_LEVEL_WARNING;
				}
				else if (strcmp(optarg, "error") == 0)
				{
					log_level = ACC_LOG_LEVEL_ERROR;
				}
				else
				{
					fprintf(stderr, "ERROR: Unknown log-level '%s'\n", optarg);
					return EXIT_FAILURE;
				}

				break;
			}
			default:
				break;
		}
	}

	pthread_mutex_init(&exploration_server.socket_write_lock, NULL);
	pthread_mutex_init(&comm_thread_data.comm_thread_data_lock, NULL);
	pthread_mutex_init(&main_thread_control.shutdown_lock, NULL);

	set_is_running(false);
	set_shutdown(false);
	comm_thread_data.client_socket = -1;

	exploration_server.server_socket = connection_open();

	if (exploration_server.server_socket < 0)
	{
		return EXIT_FAILURE;
	}

	acc_exploration_server_register_all_services();

	if (!acc_exploration_server_init(command_buffer, sizeof(command_buffer), "linux", log_level))
	{
		cleanup();
		return EXIT_FAILURE;
	}

	struct sigaction sig_a;
	sig_a.sa_handler = sig_handler;
	sig_a.sa_flags   = 0;
	sigemptyset(&sig_a.sa_mask);
	sigaction(SIGINT, &sig_a, NULL);
	signal(SIGPIPE, SIG_IGN);

	while (true)
	{
		printf("Waiting for new connections...\n");
		fflush(stdout);

		while (!check_shutdown() &&
		       ((comm_thread_data.client_socket = accept(exploration_server.server_socket, NULL, NULL)) < 0) && (errno == EINTR));

		if (check_shutdown())
		{
			break;
		}

		if (comm_thread_data.client_socket < 0)
		{
			printf("accept(): (%u) %s", errno, strerror(errno));
			continue;
		}

		if (setsockopt(comm_thread_data.client_socket, SOL_SOCKET, SO_KEEPALIVE, &(int){1 }, sizeof(int)) < 0)
		{
			printf("setsockopt(SO_KEEPALIVE): (%u) %s", errno, strerror(errno));
		}

		if (setsockopt(comm_thread_data.client_socket, IPPROTO_TCP, TCP_NODELAY, &(int){1 }, sizeof(int)) < 0)
		{
			printf("setsockopt(TCP_NODELAY): (%u) %s", errno, strerror(errno));
		}

		if (setsockopt(comm_thread_data.client_socket, SOL_SOCKET, SO_SNDBUF, &(int){200000 }, sizeof(int)) < 0)
		{
			printf("setsockopt(SO_SNDBUF): (%u) %s", errno, strerror(errno));
		}

		printf("Got new connection.\n");
		printf("Listening for command...\n");

		set_blocking(comm_thread_data.client_socket, true);

		while (true)
		{
			if (!read_line_from_client(comm_thread_data.client_socket))
			{
				printf("read_line_from_client failed\n");
				break;
			}

			if (acc_exploration_server_have_line())
			{
				acc_exploration_server_process_cmds(&server_if);
			}

			if (check_shutdown())
			{
				printf("check_shutdown is true\n");
				break;
			}
		}

		shutdown(comm_thread_data.client_socket, SHUT_WR);
		close(comm_thread_data.client_socket);
		comm_thread_data.client_socket = -1;

		stop_streaming();
		acc_exploration_server_destroy_session();
	}

	if (comm_thread_data.client_socket > 0)
	{
		printf("\nClose_connection!\n");
		acc_exploration_server_end(write_data_func);
		shutdown(comm_thread_data.client_socket, SHUT_WR);
		close(comm_thread_data.client_socket);
	}

	printf("Terminated...\n");
	cleanup();

	return EXIT_SUCCESS;
}
