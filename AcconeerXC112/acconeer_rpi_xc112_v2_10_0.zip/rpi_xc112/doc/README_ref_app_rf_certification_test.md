# A111 certification test SW

This test software for certification of the A111 sensor represent the worst-case configuration
of the sensor which the customer can select to use their own application for certification testing.

For detailed documentation, head over to the [Acconeer website](https://www.acconeer.com/products).
