var group__Log =
[
    [ "acc_rss_integration_log_t", "structacc__rss__integration__log__t.html", [
      [ "log", "structacc__rss__integration__log__t.html#ab6bf2d78ee8388a7943656c480c8e5ed", null ],
      [ "log_level", "structacc__rss__integration__log__t.html#a401ee48ba02cd63c873e85093cbb728a", null ]
    ] ],
    [ "acc_log_function_t", "group__Log.html#ga1bdb7466d8585430cece18820421628d", null ]
];