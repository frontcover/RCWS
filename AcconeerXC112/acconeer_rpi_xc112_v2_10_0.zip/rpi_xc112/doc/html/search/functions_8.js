var searchData=
[
  ['read_5fline_5ffrom_5fclient_1511',['read_line_from_client',['../acc__exploration__server__linux_8c.html#a9dad9012d4c8480dc05ddb7277e276b0',1,'acc_exploration_server_linux.c']]],
  ['record_5fbackground_1512',['record_background',['../example__detector__distance__recorded_8c.html#a545ceeb81dcfe1d8ab52cba40ae5d1ae',1,'record_background(acc_detector_distance_configuration_t distance_configuration):&#160;example_detector_distance_recorded.c'],['../ref__app__tank__level_8c.html#a1b38346b79b3e4b2bbb599743176b552',1,'record_background(acc_detector_distance_handle_t *distance_handle, acc_detector_distance_configuration_t distance_configuration, float *range_gain, uint16_t *background, uint16_t background_length):&#160;ref_app_tank_level.c']]],
  ['record_5fbackgrounds_1513',['record_backgrounds',['../ref__app__tank__level_8c.html#ab1a6c6e2c86b981a980905e1068357e9',1,'ref_app_tank_level.c']]],
  ['restart_5fservice_1514',['restart_service',['../example__error__handling_8c.html#a5d45c9e2b006f542e79d2966b9259cbd',1,'example_error_handling.c']]],
  ['run_5ftest_1515',['run_test',['../example__bring__up_8c.html#a1e6307b53e6eaff0385c6f4380c0b115',1,'example_bring_up.c']]]
];
