var searchData=
[
  ['max_5fbackground_5flength_1891',['MAX_BACKGROUND_LENGTH',['../example__detector__distance__recorded_8c.html#a1935f556b51815978f529368ce06cc00',1,'MAX_BACKGROUND_LENGTH():&#160;example_detector_distance_recorded.c'],['../ref__app__tank__level_8c.html#a1935f556b51815978f529368ce06cc00',1,'MAX_BACKGROUND_LENGTH():&#160;ref_app_tank_level.c']]],
  ['max_5fcommand_5fsize_1892',['MAX_COMMAND_SIZE',['../acc__exploration__server__linux_8c.html#ab95c4556ea9e5b815392d36c3d7b2ec0',1,'acc_exploration_server_linux.c']]],
  ['max_5fleak_5famplitude_1893',['MAX_LEAK_AMPLITUDE',['../ref__app__parking_8c.html#aacde75fc94a20bbba826af3dc6d83664',1,'ref_app_parking.c']]],
  ['max_5fspi_5ftransfer_5fsize_1894',['MAX_SPI_TRANSFER_SIZE',['../acc__libspi_8h.html#a107842648e898ef838bd58e4307ea094',1,'acc_libspi.h']]]
];
