var searchData=
[
  ['_5fgnu_5fsource_1780',['_GNU_SOURCE',['../acc__exploration__server__linux_8c.html#a369266c24eacffb87046522897a570d5',1,'_GNU_SOURCE():&#160;acc_exploration_server_linux.c'],['../acc__integration__linux_8c.html#a369266c24eacffb87046522897a570d5',1,'_GNU_SOURCE():&#160;acc_integration_linux.c']]],
  ['_5fposix_5fc_5fsource_1781',['_POSIX_C_SOURCE',['../acc__service__data__logger_8c.html#a3024ccd4a9af5109d24e6c57565d74a1',1,'acc_service_data_logger.c']]]
];
