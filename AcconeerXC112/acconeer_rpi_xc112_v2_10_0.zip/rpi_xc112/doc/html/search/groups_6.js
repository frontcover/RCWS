var searchData=
[
  ['log_20integration_1920',['Log Integration',['../group__Log.html',1,'']]]
];
