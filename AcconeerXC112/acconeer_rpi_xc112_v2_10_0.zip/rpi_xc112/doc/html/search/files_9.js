var searchData=
[
  ['smart_5fpresence_2emd_1066',['smart_presence.md',['../smart__presence_8md.html',1,'']]],
  ['sparse_2emd_1067',['sparse.md',['../sparse_8md.html',1,'']]]
];
