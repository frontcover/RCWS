var searchData=
[
  ['amplitude_1535',['amplitude',['../structacc__detector__distance__result__t.html#a59f78d4e2c7375565d0363867f007fe1',1,'acc_detector_distance_result_t::amplitude()'],['../structacc__obstacle__t.html#ac2e03a1e4ab158c8054df76a96b99eb8',1,'acc_obstacle_t::amplitude()']]]
];
