var searchData=
[
  ['sensor_5fid_1903',['SENSOR_ID',['../ref__app__parking_8c.html#af59052da2439dbf99ccf29a3f8bf9399',1,'ref_app_parking.c']]],
  ['service_5fdownsampling_1904',['SERVICE_DOWNSAMPLING',['../ref__app__parking_8c.html#a830d3ceaa9b95374ff672c8d329bd940',1,'ref_app_parking.c']]],
  ['service_5fhwaas_1905',['SERVICE_HWAAS',['../ref__app__parking_8c.html#a71b410273fc7911192ba3512aa070858',1,'ref_app_parking.c']]],
  ['service_5fruntime_5fmin_5fs_1906',['SERVICE_RUNTIME_MIN_S',['../ref__app__parking_8c.html#ad62dbcfe5d86a73eb61beda6b9372406',1,'ref_app_parking.c']]],
  ['service_5fuptime_5fmax_5fs_1907',['SERVICE_UPTIME_MAX_S',['../ref__app__parking_8c.html#ab05011b0ccafaacaae61b83f0156e88e',1,'ref_app_parking.c']]],
  ['sparse_5fdata_5fformat_5fbufsize_1908',['SPARSE_DATA_FORMAT_BUFSIZE',['../acc__service__data__logger_8c.html#aa216b7b2f519a30ebae382a408b89fe5',1,'acc_service_data_logger.c']]],
  ['spidev_5fpath_1909',['SPIDEV_PATH',['../acc__libspi_8c.html#a5922418acdcec90cfe31a0203afff97e',1,'acc_libspi.c']]]
];
