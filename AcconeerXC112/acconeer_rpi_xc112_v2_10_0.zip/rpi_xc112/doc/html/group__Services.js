var group__Services =
[
    [ "Generic Service API", "group__Generic.html", "group__Generic" ],
    [ "Envelope Service", "group__Envelope.html", "group__Envelope" ],
    [ "IQ Service", "group__IQ.html", "group__IQ" ],
    [ "Power Bins Service", "group__Power.html", "group__Power" ],
    [ "Sparse Service", "group__Sparse.html", "group__Sparse" ]
];