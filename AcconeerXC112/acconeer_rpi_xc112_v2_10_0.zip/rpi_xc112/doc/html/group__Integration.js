var group__Integration =
[
    [ "OS Integration", "group__OS.html", "group__OS" ],
    [ "Hardware Integration", "group__HAL.html", "group__HAL" ],
    [ "Integration Properties", "group__Properties.html", "group__Properties" ],
    [ "Log Integration", "group__Log.html", "group__Log" ],
    [ "acc_hal_t", "structacc__hal__t.html", [
      [ "log", "structacc__hal__t.html#ab4344709aaf67f251c0ce8f50908daef", null ],
      [ "os", "structacc__hal__t.html#a2a2c1593eb8a09916aa7b83055033abc", null ],
      [ "properties", "structacc__hal__t.html#a1c1672f8f6a5600ab856076384328f0c", null ],
      [ "sensor_device", "structacc__hal__t.html#a9972bb8a8daa5e7fe8b22da97038ac64", null ]
    ] ]
];