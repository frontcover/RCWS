var group__HAL =
[
    [ "acc_rss_integration_sensor_device_t", "structacc__rss__integration__sensor__device__t.html", [
      [ "get_reference_frequency", "structacc__rss__integration__sensor__device__t.html#a57c8db10bc444bb876bc357ac57dcf3c", null ],
      [ "hibernate_enter", "structacc__rss__integration__sensor__device__t.html#a4accf3625ad2fa2eb774bddf55d5d9dc", null ],
      [ "hibernate_exit", "structacc__rss__integration__sensor__device__t.html#a45af8c526db36b63520613f78234d9b1", null ],
      [ "power_off", "structacc__rss__integration__sensor__device__t.html#a78f841c9ca2b7516ae7ea85fa21d76b6", null ],
      [ "power_on", "structacc__rss__integration__sensor__device__t.html#a646d7a7e1ab2ca6d2d29c9e6b728ab95", null ],
      [ "transfer", "structacc__rss__integration__sensor__device__t.html#a542d724b651c5841265ac6e2d91dbae6", null ],
      [ "wait_for_interrupt", "structacc__rss__integration__sensor__device__t.html#a0d221d861e0b73fd50d9d5ccd896a5c6", null ]
    ] ],
    [ "acc_hal_get_frequency_function_t", "group__HAL.html#ga8eed346aab46a15848ec42cdcd1fced2", null ],
    [ "acc_hal_sensor_power_function_t", "group__HAL.html#ga198694f53811c55fdec7e440b4d5d691", null ],
    [ "acc_hal_sensor_transfer_function_t", "group__HAL.html#ga291d457e3ada369072de2ba35c57b969", null ],
    [ "acc_hal_sensor_wait_for_interrupt_function_t", "group__HAL.html#ga3d99fa90b8aaad3baa9e05dd61c8f4f4", null ]
];